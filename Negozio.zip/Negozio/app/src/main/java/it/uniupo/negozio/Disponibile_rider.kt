package it.uniupo.negozio

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Disponibile_rider : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_disponibile_rider)

        val si = findViewById<Button>(R.id.but1)

        si.setOnClickListener {
            val intent_organizza_rider = Intent(this, Rider::class.java)
            startActivity(intent_organizza_rider)
        }

        val no = findViewById<Button>(R.id.but2)

        no.setOnClickListener {
            val intent_log = Intent(this, Rider_o_cliente::class.java)
            startActivity(intent_log)
        }
    }
}