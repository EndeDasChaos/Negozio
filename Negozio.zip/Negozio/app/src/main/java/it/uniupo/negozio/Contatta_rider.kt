package it.uniupo.negozio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import kotlin.collections.mapOf as mapOf1

class Contatta_rider : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contatta_rider)
    }/*
    private fun sendMessage() {
        val newMessage = mapOf1(
                NAME_FIELD to edit_name.text.toString()
                TEXT_FIELD to edit_message.text.toString())

        firestoreChat.set(newMessage)
                .addOnSuccessListener( {
                    Toast.makeText(this, "Message Sent", Toast.LENGTH_SHORT).show()
                })
                .addOnFailureListener { e -> Log.e("ERROR", e.message) }
    }
    private fun addRealtimeUpdate() {
        firestoreChat.addSnapshotListener { documentSnapshot, e ->
            when {
                e != null -> Log.e("ERROR", e.message)
                documentSnapshot != null
                        && documentSnapshot.exists() ->{
                    with(documentSnapshot) {
                        textDisplay.text = "${data[NAME_FIELD]}:${data[TEXT_FIELD]}"
                    }
                }
            }
        }
    }
*/
}