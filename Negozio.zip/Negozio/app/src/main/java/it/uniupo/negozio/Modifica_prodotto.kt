package it.uniupo.negozio

import android.R.attr.password
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore


class Modifica_prodotto : AppCompatActivity() {
    var NOME: String? = null
    var EURO: kotlin.String? = null
    var NUMERO: kotlin.String? = null
    var DESCR: kotlin.String? = null

    val data = FirebaseFirestore.getInstance()
    val TAG = "***data"
    var reference = FirebaseDatabase.getInstance().getReference("prodotti");
    val nome_prodotto = findViewById<TextView>(R.id.nome)
    val prezzo = findViewById<TextView>(R.id.euro)
    val quantitativo = findViewById<TextView>(R.id.numero)
    val descrizione = findViewById<TextView>(R.id.descr)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modifica_prodotto)

        val pro = findViewById<TextView>(R.id.informazione)
        val visualizza = findViewById<Button>(R.id.but1)
        val modifica = findViewById<Button>(R.id.but2)


        /*showAllData()*/

        visualizza.setOnClickListener {
            /* read(pro)*/
        }
        modifica.setOnClickListener {

        }
    }
}
/*
    private fun showAllData() {

        val nome_prodotto = findViewById<TextView>(R.id.nome)
        val prezzo = findViewById<TextView>(R.id.euro)
        val quantitativo = findViewById<TextView>(R.id.numero)
        val descrizione = findViewById<TextView>(R.id.descr)

        val intent = intent
        NOME = intent.getStringExtra("nome")
        EURO = intent.getStringExtra("euro")
        NUMERO = intent.getStringExtra("numero")
        DESCR = intent.getStringExtra("descr")

        nome_prodotto.text = NOME
        prezzo.text = EURO
        quantitativo.text = NUMERO
        descrizione.text = DESCR


    }

    fun update(view: View?) {
        if(isNameChanged() ||isPasswordChanged()){
            Toast.makeText(this, "modifica effettuata", Toast.LENGTH_LONG).show()
        }
        else   Toast.makeText(this, "nessuna modifica", Toast.LENGTH_LONG).show()

    }
    private fun isPasswordChanged(): Boolean {
        return if (!_PASSWORD.equals(password.getEditText().getText().toString())) {
            reference.child(_USERNAME).child("password")
                .setValue(password.getEditText().getText().toString())
            _PASSWORD = password.getEditText().getText().toString()
            true
        } else {
            false
        }
    }

    private fun isNameChanged(): Boolean {
        return if (!_NAME.equals(fullName.getEditText().getText().toString())) {
            reference.child(_USERNAME).child("name")
                .setValue(fullName.getEditText().getText().toString())
            _NAME = fullName.getEditText().getText().toString()
            true
        } else {
            false
        }
    }

}/*
    private fun read(pro: TextView){
        data.collection("prodotti")
            .get()
            .addOnCompleteListener(OnCompleteListener<QuerySnapshot> { task ->
                if (task.isSuccessful) {
                    pro.text = ""
                    for (document in task.result!!) {
                        pro.text =
                            "${pro.text} ${document["nome"]} ${document["descr"]} ${document["euro"]}${document["numero"]}\n"
                    }
                } else {
                    Log.w(TAG, "Error getting documents.", task.exception)
                }
            })
    }*/